//
// Created by Marcel Ghisi on 17/11/21.
//

#ifndef MY_BC_PY_UTILS_H
#define MY_BC_PY_UTILS_H

void print_int_std_out(int value);
void print_version();

#endif //MY_BC_PY_UTILS_H
