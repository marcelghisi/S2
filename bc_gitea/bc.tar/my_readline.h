//
// Created by Marcel Ghisi on 16/11/21.
//

#ifndef MY_BC_PY_MY_READLINE_H
#define MY_BC_PY_MY_READLINE_H

#define BUFF_SIZE 10
#define READLINE_READ_SIZE 2000

char* my_readline(int fd);

int my_putchar(char c);

void my_putstr(char* param_1);

#endif //MY_BC_PY_MY_READLINE_H

